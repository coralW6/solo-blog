title: django基础入门
date: '2019-04-30 20:33:30'
updated: '2019-04-30 20:33:30'
tags: [django, python]
permalink: /articles/2019/04/30/1556627610077.html
---
django是一个python语言开发的web框架。
主要的组件以及特点
* 强大的数据库功能
* 自带后台管理功能
* 优雅的网址
* 模板系统
* 缓存系统
* 国际化

### 1 搭建项目

安装python2.7或者python3均可，安装pip（默认都有啦）

#### 1.1 安装django

默认安装最新版

`(sudo) pip install django`

指定版本安装

`(sudo) pip install django==1.11.11 `

安装如果遇到速度太慢或者超时，可以使用国内镜像安装

`(sudo) pip install django -i https://pypi.doubanio.com/simple/`

安装后就可以下一步搭建项目

#### 1.2 创建一个django项目

##### 1.2.1 创建一个项目目录（已有也行）

`mkdir django_test`

##### 1.2.2 进入该目录

`cd django_test`

##### 1.2.3 执行该命令创建一个django项目

`django-admin.py startproject family`

##### 1.2.4 进入family目录后执行

`python manage.py runserver` 或者指定端口 `python manage.py runserver 8081`

在浏览器输入 http://127.0.0.1:8000/ 就可以打开看到 It worked! 字样，表示django项目创建成功

#### 1.3 创建一个django工程

`python manage.py startapp family_app`

注意点：工程名中不能有中划线

#### 1.4 配置我们的工程

需要在family/settings.py中做一些配置

##### 1.4.1 INSTALLED_APPS列表中注册我们的工程名

##### 1.4.2 配置数据库(mysql)
默认我们本地都安装了mysql（建议5.6+）
在DATABASES字典中注释掉自带的数据库，使用我们自己配置的mysql
```
    'default': {
       'ENGINE': 'django.db.backends.mysql',
       'NAME': 'family_app',
       'USER': 'wanglei',
       'PASSWORD': 'xxxxxx',
       'HOST': '127.0.0.1',
       'PORT': '3306'
   },

```

注意点：如果mysql版本是5.7+，需要在family/__init__.py中加入
```
    import pymysql
    pymysql.install_as_MySQLdb()
```
原因是直接使用mysql和mysqlDb的不兼容，不能直接使用mysqlDb模块，需要使用pymysql替代

##### 1.4.3 数据库中创建一些django自带的表
`python manage.py migrate`

到此为止，整个项目和工程的基本配置就完成了。

###  2 helloWorld起步

#### 2.1 工程中的文件结构介绍
* migrations：数据迁移模块
* admin.py：后台管理系统
* apps.py：应用的一些配置，1.9以后自动生成
* models.py：数据模块
* tests.py：自动化测试的模块
* views.py：执行响应的代码所在模块，是代码逻辑处理的主要地点，项目中大部分代码在这里编写

#### 2.2 第一行代码

* 在family/urls.py中引入我们工程中的views，然后配置路由
```
    import family_app.views as views
    urlpatterns = [
        url(r'^admin/', admin.site.urls),
        url(r'^$', views.index),
    ]
```

* family_app/views.py中写我们要展示在界面的逻辑
```
    from django.http import HttpResponse, JsonResponse
    def index(request):
        ret_str = "hello world"
        print ret_str
        return HttpResponse(ret_str)
```

* 刷新界面，就可以看到hello world了

### 3 渲染模板

#### 3.1 模板渲染入门
将后端返回的结构化数据渲染到模板上

* 在family_app目录下创建templates目录，管理前端模板
* 在family/settings.py的TEMPLATES中DIRS列表中加入'family_app/templates'
* 在templates目录下创建index.html文件，并写代码
```
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Title</title>
    </head>
    <body>
        <div>
            <h3>这就是后端返回的数据 {{ data }}</h3>
        </div>
    </body>
    </html>
```

* family_app/views.py中修改响应的方式
```
    return render(request, 'index.html', {'data': ret_str})
```
一个简单的模板渲染就完成了

#### 3.2 一些基础的渲染方式
* 列表渲染

family_app/views.py
```
    ret_str = ["hello world", "1024"]
    return render(request, 'index.html', {'data': ret_str})
```
templates/index.html
```
    <div>
        {% for item in data %}
            <p>{{ item }}</p>
        {% endfor %}
    </div>
```
* 字典渲染
family_app/views.py
```
    ret_str = {"k1": "hello", "k2": "world", "k3": "1024"}
    return render(request, 'index.html', {'data': ret_str})
```
templates/index.html
```
    遍历取值
    <div>
        {% for key, val in data.items %}
            <p>key:{{ key }} val:{{ val }}</p>
        {% endfor %}
    </div>
    按key取值
    <div>
        {{ data.k3 }}
    </div>
```

4 包含静态资源的模板渲染

在以上的基础上，我们加上js和css的操作
* 在family_app目录下创建static目录，管理静态资源
* 在family/settings.py中添加
```
    STATIC_ROOT = os.path.join(BASE_DIR, "family_app/static")
```
* 在family_app/static/index.js，并添加代码
```
    function click_submit()
    {
        alert("别点了！");
    }
```

* 在family_app/static/index.css，并添加代码
```
    .list-css {
        margin-left:200px;
    }
```

* 在index.html中添加
```
    {% load static %}
    <link rel="stylesheet" href="{% static 'index.css' %}" type="text/css">
    <script src="static/index.js"></script>

    <div onclick="click_submit()">点击按钮</div>
```

以上就是前端静态资源在页面加载过程中的具体配置方式

### 4 后端请求数据库

先不使用django的model，我们自己连接数据库去请求

#### 4.1 创建数据库表并写几条数据进去
```
    create table family_app.user (
      id int(11) NOT NULL AUTO_INCREMENT,
      number bigint(20) NOT NULL COMMENT '用户编号',
      name varchar(45) DEFAULT NULL COMMENT '用户名',
      mobile varchar(20) DEFAULT NULL COMMENT '手机号',
      status tinyint(4) DEFAULT '1' COMMENT '用户状态',
      create_time timestamp DEFAULT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
      update_time timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
      PRIMARY KEY (id),
      UNIQUE KEY uniq_number (number),
      KEY idx_mobile (mobile),
      KEY idx_update_time (update_time)
    ) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8 COMMENT="用户表";
```
```
    insert into family_app.user (number, name, mobile, status) values (1000, "张三", "13100000000", 1);
```

#### 4.2 连接数据库并写sql请求数据
```
from django.db import connection, models
import traceback

def get_user_info(request):
    number = 0
    if 'number' in request.GET and request.GET['number'] != 0:
        number = int(request.GET['number'])

    user_sql = """
        select number, name, mobile from family_app.user where status=1 and number=%s
    """ % number
    print "user_sql:", user_sql
    ret = execute(user_sql)

    ret_list = []
    for r in ret:
        print r[0], r[1], r[2]
        user_dict = {"number": r[0], "name": r[1], "mobile": r[2]}
        ret_list.append(user_dict)
    return render(request, 'index.html', {'data': ret_list})

def execute(sql, params=None, auto_close=True):
    cur = None
    try:
        sql = sql.strip()
        cur = connection.cursor()
        cur.execute(sql, params)
        result = cur.fetchall()
        #print "ret_len:", len(result)
        return result
    except Exception, e:
        if params:
            print sql % params
        else:
            print sql
        traceback.print_exc()
    finally:
        if cur and auto_close:
            cur.close()

```

#### 4.3 url配置接口名
```
    url(r'^get_user_info', views.get_user_info)
```

#### 4.4 index.html中写渲染代码
```
    <div>
        {% for item_dict in data %}
            {% for key, val in item_dict.items %}
                <p>key:{{ key }} val:{{ val }}</p>
            {% endfor %}
        {% endfor %}
    </div>
```

以上开发和配置完成后浏览器访问 http://127.0.0.1:8000/get_user_info?number=1000 就可以看到数据库中的数据在页面的渲染

### 5 后台管理的简单使用

终端执行命令创建超级管理员并登陆

```python manage.py createsuperuser```

然后在http://127.0.0.1:8000/admin中登陆进入后台管理界面

例如需要在后台管理我们创建的family_app.user表，做一些常规的增删改查。

#### 5.1 创建一个新的工程

`python manage.py startapp family_user_admin`

 并将该工程注册到 family/settings.py的INSTALLED_APPS列表中

#### 5.2 开发models模块

将我们的family_app.user表结构中需要我们修改的字段映射到发model中

```
    check_status = (
        (0, '不生效'),
        (1, '生效'),
    )

    class MyUser(models.Model):
        id = models.BigIntegerField(verbose_name='id', editable=False, primary_key=True, unique=True)
        number = models.BigIntegerField(verbose_name='用户number', editable=True)
        name = models.CharField(verbose_name='用户名', max_length=1024, blank=True)
        mobile = models.CharField(verbose_name='电话', max_length=1024, blank=True)
        status = models.IntegerField(verbose_name='用户状态', choices=check_status)

        class Meta:
            db_table = 'user'
```

#### 5.3 开发admin模块

将我们model中的需要展示和修改的字段添加到管理界面中

```
    from models import MyUser
    class MyUserAdmin(admin.ModelAdmin):
        list_display = ('number', 'name', 'mobile', 'status')
        search_fields = ('number', 'name', 'mobile')


        def has_delete_permission(self, request, obj=None):
            return False

    admin.site.register(MyUser, MyUserAdmin)
```

操作完以上步骤后在admin界面中可以看到我们的新增的管理模块MyUsers，点击进去就可以看到配置的信息，可以做增删改查操作